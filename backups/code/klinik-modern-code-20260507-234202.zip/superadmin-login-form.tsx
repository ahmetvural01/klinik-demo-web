"use client";

import { FormEvent, useState } from "react";

export function SuperadminLoginForm() {
  const [identityNo, setIdentityNo] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError(null);

    const res = await fetch("/api/auth/superadmin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identityNo, password }),
    });

    setLoading(false);

    if (!res.ok) {
      const message = await res.json().catch(() => ({ message: "Giriş başarısız" }));
      setError(message.message || "Giriş başarısız");
      return;
    }

    window.location.href = "/superadmin/panel";
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 flex items-center justify-center p-4">
      <form onSubmit={onSubmit} className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 backdrop-blur p-7 text-white shadow-2xl">
        <div className="mb-6">
          <p className="text-xs tracking-widest text-emerald-300">YÖNETİM PANELİ</p>
          <h1 className="mt-2 text-3xl font-black">Yonetici Girisi</h1>
          <p className="mt-1 text-sm text-slate-300">Sistem yonetimi icin kimlik bilgilerinizi girin.</p>
        </div>

        <label className="mb-4 block text-sm font-semibold text-slate-200">
          TC Kimlik No
          <input
            className="mt-1 w-full rounded-xl border border-white/20 bg-white/5 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-300"
            value={identityNo}
            onChange={(e) => setIdentityNo(e.target.value)}
            placeholder="11 haneli"
            required
          />
        </label>

        <label className="mb-4 block text-sm font-semibold text-slate-200">
          Sifre
          <input
            className="mt-1 w-full rounded-xl border border-white/20 bg-white/5 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-300"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>

        {error && <p className="mb-3 text-sm text-rose-300">{error}</p>}

        <button disabled={loading} className="w-full rounded-xl bg-emerald-500 p-3 text-sm font-bold text-slate-900 hover:bg-emerald-400 transition disabled:opacity-50">
          {loading ? "Doğrulanıyor..." : "Sisteme Giriş"}
        </button>
      </form>
    </main>
  );
}
